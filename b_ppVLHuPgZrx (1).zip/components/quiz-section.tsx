'use client';

import { useState, useEffect } from 'react';
import { CheckCircle2, XCircle, Clock, ChevronRight, AlertCircle, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useAppStore, calculateSkillLevel, generateStudyPlanDescription, generateInitialProgress } from '@/lib/store';
import { getQuestionsByStream, getSubjectsByStream } from '@/lib/quiz-data';
import { Question, SkillLevel, QuizResult } from '@/lib/types';
import { cn } from '@/lib/utils';

const skillLevelColors = {
  beginner: 'bg-secondary text-secondary-foreground',
  intermediate: 'bg-accent text-accent-foreground',
  advanced: 'bg-primary text-primary-foreground',
};

const skillLevelDescriptions = {
  beginner: 'Foundation Builder',
  intermediate: 'Knowledge Explorer',
  advanced: 'Subject Master',
};

export function QuizSection() {
  const { student, setQuizResult, setCurrentView, setProgress } = useAppStore();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [showResult, setShowResult] = useState(false);
  const [result, setResult] = useState<QuizResult | null>(null);
  const [timeLeft, setTimeLeft] = useState(900); // 15 minutes

  const questions = student ? getQuestionsByStream(student.stream) : [];
  const subjects = student ? getSubjectsByStream(student.stream) : [];
  const currentQuestion = questions[currentQuestionIndex];
  const progressPercentage = ((currentQuestionIndex + 1) / questions.length) * 100;

  // Timer
  useEffect(() => {
    if (showResult || timeLeft <= 0) return;
    
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleSubmitQuiz();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [showResult, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSelectAnswer = (optionIndex: number) => {
    setSelectedAnswer(optionIndex);
  };

  const handleNextQuestion = () => {
    if (selectedAnswer === null || !currentQuestion) return;

    const newAnswers = {
      ...answers,
      [currentQuestion.id]: selectedAnswer,
    };
    setAnswers(newAnswers);
    setSelectedAnswer(null);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      calculateResult(newAnswers);
    }
  };

  const handleSubmitQuiz = () => {
    const finalAnswers = selectedAnswer !== null && currentQuestion
      ? { ...answers, [currentQuestion.id]: selectedAnswer }
      : answers;
    calculateResult(finalAnswers);
  };

  const calculateResult = (finalAnswers: Record<string, number>) => {
    if (!student) return;

    let totalScore = 0;
    const subjectScores: Record<string, { correct: number; total: number }> = {};

    subjects.forEach((subject) => {
      subjectScores[subject] = { correct: 0, total: 0 };
    });

    questions.forEach((question) => {
      const userAnswer = finalAnswers[question.id];
      subjectScores[question.subject].total += 1;
      
      if (userAnswer === question.correctAnswer) {
        totalScore += 1;
        subjectScores[question.subject].correct += 1;
      }
    });

    const skillLevel = calculateSkillLevel(totalScore, questions.length);

    const quizResult: QuizResult = {
      studentId: student.id,
      stream: student.stream,
      answers: finalAnswers,
      score: totalScore,
      totalQuestions: questions.length,
      skillLevel,
      subjectScores,
      completedAt: new Date(),
    };

    setResult(quizResult);
    setQuizResult(quizResult);
    setProgress(generateInitialProgress(student.id, student.stream));
    setShowResult(true);
  };

  if (!student) return null;

  if (showResult && result) {
    return (
      <div className="min-h-screen bg-background py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Card className="border-2 border-primary/20 overflow-hidden">
            <div className="bg-gradient-to-r from-primary/10 to-secondary/10 p-8 text-center">
              <div className={cn(
                'mx-auto mb-4 inline-flex items-center gap-2 rounded-full px-6 py-2 text-lg font-medium',
                skillLevelColors[result.skillLevel]
              )}>
                <Sparkles className="h-5 w-5" />
                {skillLevelDescriptions[result.skillLevel]}
              </div>
              
              <h2 className="text-3xl font-bold mb-2">Assessment Complete!</h2>
              <p className="text-muted-foreground">
                You scored {result.score} out of {result.totalQuestions} questions
              </p>
              
              <div className="mt-6 flex justify-center items-center gap-8">
                <div className="text-center">
                  <p className="text-5xl font-bold text-primary">
                    {Math.round((result.score / result.totalQuestions) * 100)}%
                  </p>
                  <p className="text-sm text-muted-foreground">Overall Score</p>
                </div>
              </div>
            </div>
            
            <CardContent className="p-8">
              {/* Subject-wise Analysis */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold mb-4">Subject-wise Performance</h3>
                <div className="grid gap-4">
                  {Object.entries(result.subjectScores).map(([subject, scores]) => {
                    const percentage = (scores.correct / scores.total) * 100;
                    return (
                      <div key={subject} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{subject}</span>
                          <span className="text-sm text-muted-foreground">
                            {scores.correct}/{scores.total} correct ({Math.round(percentage)}%)
                          </span>
                        </div>
                        <Progress value={percentage} className="h-3" />
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Skill Level Analysis */}
              <Card className="bg-muted/30 border-0 mb-8">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-primary" />
                    Your Learning Path
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-start gap-4 mb-4">
                    <div className={cn(
                      'shrink-0 rounded-lg px-4 py-2 text-sm font-medium capitalize',
                      skillLevelColors[result.skillLevel]
                    )}>
                      {result.skillLevel}
                    </div>
                    <p className="text-muted-foreground">
                      {generateStudyPlanDescription(result.skillLevel, student.stream)}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Study Plan Preview */}
              <div className="mb-8">
                <h3 className="text-lg font-semibold mb-4">Recommended Focus Areas</h3>
                <div className="grid sm:grid-cols-3 gap-4">
                  {subjects.map((subject) => {
                    const scores = result.subjectScores[subject];
                    const percentage = (scores.correct / scores.total) * 100;
                    const priority = percentage < 40 ? 'High Priority' : percentage < 70 ? 'Medium Priority' : 'On Track';
                    const priorityColor = percentage < 40 ? 'text-destructive' : percentage < 70 ? 'text-secondary' : 'text-primary';
                    
                    return (
                      <Card key={subject} className="bg-card">
                        <CardContent className="pt-6">
                          <h4 className="font-semibold mb-1">{subject}</h4>
                          <p className={cn('text-sm font-medium', priorityColor)}>{priority}</p>
                          <p className="text-xs text-muted-foreground mt-2">
                            {percentage < 40 
                              ? 'Focus on fundamentals and basic concepts'
                              : percentage < 70 
                                ? 'Practice more problems and applications'
                                : 'Keep up the good work!'}
                          </p>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="flex-1 gap-2"
                  onClick={() => setCurrentView('progress')}
                >
                  View Progress Dashboard
                  <ChevronRight className="h-5 w-5" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  className="flex-1 gap-2"
                  onClick={() => setCurrentView('topics')}
                >
                  Start Study Plan
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Current subject being tested
  const currentSubject = currentQuestion?.subject || '';
  const questionNumber = currentQuestionIndex + 1;

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-3xl">
        {/* Quiz Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold">Skill Assessment</h1>
              <p className="text-muted-foreground">{student.stream} Stream - {currentSubject}</p>
            </div>
            <div className={cn(
              'flex items-center gap-2 rounded-full px-4 py-2 font-mono text-lg',
              timeLeft < 300 ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'
            )}>
              <Clock className="h-5 w-5" />
              {formatTime(timeLeft)}
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Question {questionNumber} of {questions.length}</span>
              <span>{Math.round(progressPercentage)}% Complete</span>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </div>
        </div>

        {/* Question Card */}
        <Card className="border-2">
          <CardHeader>
            <div className="flex items-center gap-2 mb-2">
              <span className="inline-flex items-center rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                {currentSubject}
              </span>
              <span className="inline-flex items-center rounded-full bg-muted px-3 py-1 text-xs font-medium text-muted-foreground capitalize">
                {currentQuestion?.difficulty}
              </span>
            </div>
            <CardTitle className="text-xl leading-relaxed">
              {currentQuestion?.text}
            </CardTitle>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {currentQuestion?.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleSelectAnswer(index)}
                className={cn(
                  'w-full flex items-center gap-4 rounded-xl border-2 p-4 text-left transition-all hover:border-primary/50',
                  selectedAnswer === index
                    ? 'border-primary bg-primary/5'
                    : 'border-border bg-card'
                )}
              >
                <span className={cn(
                  'flex h-10 w-10 shrink-0 items-center justify-center rounded-full font-semibold',
                  selectedAnswer === index
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground'
                )}>
                  {String.fromCharCode(65 + index)}
                </span>
                <span className="font-medium">{option}</span>
              </button>
            ))}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="mt-6 flex justify-between">
          <Button
            variant="outline"
            onClick={handleSubmitQuiz}
            disabled={Object.keys(answers).length === 0 && selectedAnswer === null}
          >
            Submit Quiz
          </Button>
          
          <Button
            onClick={handleNextQuestion}
            disabled={selectedAnswer === null}
            className="gap-2"
          >
            {currentQuestionIndex < questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
            <ChevronRight className="h-5 w-5" />
          </Button>
        </div>

        {/* Subject Progress */}
        <div className="mt-8 grid grid-cols-3 gap-4">
          {subjects.map((subject) => {
            const subjectQuestions = questions.filter(q => q.subject === subject);
            const answeredCount = subjectQuestions.filter(q => answers[q.id] !== undefined).length;
            const isCurrent = subject === currentSubject;
            
            return (
              <Card key={subject} className={cn('transition-all', isCurrent && 'ring-2 ring-primary')}>
                <CardContent className="py-4">
                  <p className="font-medium text-sm">{subject}</p>
                  <p className="text-xs text-muted-foreground">
                    {answeredCount}/{subjectQuestions.length} answered
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
