'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { GraduationCap, BookOpen, Beaker, Calculator, Dna, Sparkles, ArrowRight, Users, Trophy, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAppStore } from '@/lib/store';
import { Stream } from '@/lib/types';
import { cn } from '@/lib/utils';

const registrationSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email'),
  phone: z.string().min(10, 'Please enter a valid phone number'),
});

type RegistrationData = z.infer<typeof registrationSchema>;

const features = [
  { icon: BookOpen, title: 'Adaptive Assessment', description: 'Smart quiz to evaluate your current level' },
  { icon: Trophy, title: 'Personalized Plans', description: 'Custom study schedules for your needs' },
  { icon: Clock, title: 'Progress Tracking', description: 'Monitor your improvement daily' },
  { icon: Sparkles, title: 'AI Tutor', description: '24/7 doubt clearing assistant' },
];

const stats = [
  { value: '10K+', label: 'Students' },
  { value: '95%', label: 'Success Rate' },
  { value: '500+', label: 'Topics' },
  { value: '24/7', label: 'Support' },
];

export function RegistrationForm() {
  const [selectedStream, setSelectedStream] = useState<Stream | null>(null);
  const { setStudent, setCurrentView } = useAppStore();

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<RegistrationData>({
    resolver: zodResolver(registrationSchema),
  });

  const onSubmit = (data: RegistrationData) => {
    if (!selectedStream) return;

    const student = {
      id: crypto.randomUUID(),
      name: data.name,
      email: data.email,
      phone: data.phone,
      stream: selectedStream,
      registeredAt: new Date(),
    };

    setStudent(student);
    setCurrentView('quiz');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-12 lg:py-20">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />
        
        <div className="container relative mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm text-primary">
                <Sparkles className="h-4 w-4" />
                <span>AI-Powered Learning Platform</span>
              </div>
              
              <h1 className="text-4xl lg:text-6xl font-bold tracking-tight text-balance">
                Master Your
                <span className="text-primary"> Entrance Exam</span>
                <br />
                with Adaptive Learning
              </h1>
              
              <p className="text-lg text-muted-foreground max-w-xl text-pretty">
                EduAdapt personalizes your study journey based on your skill level. 
                Take our assessment quiz and get a customized study plan designed just for you.
              </p>

              {/* Stats */}
              <div className="grid grid-cols-4 gap-4">
                {stats.map((stat) => (
                  <div key={stat.label} className="text-center">
                    <p className="text-2xl lg:text-3xl font-bold text-primary">{stat.value}</p>
                    <p className="text-xs text-muted-foreground">{stat.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Registration Card */}
            <Card className="border-2 border-border shadow-xl">
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary">
                  <GraduationCap className="h-8 w-8 text-primary-foreground" />
                </div>
                <CardTitle className="text-2xl">Register for Entrance Exam</CardTitle>
                <CardDescription>
                  Start your journey with a quick skill assessment
                </CardDescription>
              </CardHeader>
              
              <CardContent>
                <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
                  {/* Stream Selection */}
                  <div className="space-y-3">
                    <label className="text-sm font-medium text-foreground">Select Your Stream</label>
                    <div className="grid grid-cols-2 gap-4">
                      <button
                        type="button"
                        onClick={() => setSelectedStream('MPC')}
                        className={cn(
                          'relative flex flex-col items-center gap-3 rounded-xl border-2 p-6 transition-all hover:border-primary/50',
                          selectedStream === 'MPC'
                            ? 'border-primary bg-primary/5'
                            : 'border-border bg-card'
                        )}
                      >
                        <div className={cn(
                          'flex h-12 w-12 items-center justify-center rounded-xl',
                          selectedStream === 'MPC' ? 'bg-primary text-primary-foreground' : 'bg-muted'
                        )}>
                          <Calculator className="h-6 w-6" />
                        </div>
                        <div className="text-center">
                          <p className="font-semibold">MPC</p>
                          <p className="text-xs text-muted-foreground">Maths, Physics, Chemistry</p>
                        </div>
                        {selectedStream === 'MPC' && (
                          <div className="absolute top-3 right-3 h-3 w-3 rounded-full bg-primary" />
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => setSelectedStream('BIPC')}
                        className={cn(
                          'relative flex flex-col items-center gap-3 rounded-xl border-2 p-6 transition-all hover:border-secondary/50',
                          selectedStream === 'BIPC'
                            ? 'border-secondary bg-secondary/10'
                            : 'border-border bg-card'
                        )}
                      >
                        <div className={cn(
                          'flex h-12 w-12 items-center justify-center rounded-xl',
                          selectedStream === 'BIPC' ? 'bg-secondary text-secondary-foreground' : 'bg-muted'
                        )}>
                          <Dna className="h-6 w-6" />
                        </div>
                        <div className="text-center">
                          <p className="font-semibold">BIPC</p>
                          <p className="text-xs text-muted-foreground">Biology, Physics, Chemistry</p>
                        </div>
                        {selectedStream === 'BIPC' && (
                          <div className="absolute top-3 right-3 h-3 w-3 rounded-full bg-secondary" />
                        )}
                      </button>
                    </div>
                    {!selectedStream && (
                      <p className="text-xs text-muted-foreground text-center">
                        Please select your stream to continue
                      </p>
                    )}
                  </div>

                  {/* Form Fields */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Full Name</label>
                      <Input
                        {...register('name')}
                        placeholder="Enter your full name"
                        className="h-12"
                      />
                      {errors.name && (
                        <p className="text-xs text-destructive">{errors.name.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Email Address</label>
                      <Input
                        {...register('email')}
                        type="email"
                        placeholder="you@example.com"
                        className="h-12"
                      />
                      {errors.email && (
                        <p className="text-xs text-destructive">{errors.email.message}</p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Phone Number</label>
                      <Input
                        {...register('phone')}
                        type="tel"
                        placeholder="Enter your phone number"
                        className="h-12"
                      />
                      {errors.phone && (
                        <p className="text-xs text-destructive">{errors.phone.message}</p>
                      )}
                    </div>
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    className="w-full h-12 text-base gap-2"
                    disabled={!selectedStream || isSubmitting}
                  >
                    Start Assessment
                    <ArrowRight className="h-5 w-5" />
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">How EduAdapt Works</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our intelligent platform adapts to your learning style and pace
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={feature.title} className="border-0 bg-card shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex flex-col items-center text-center gap-4">
                      <div className="relative">
                        <div className="absolute -top-1 -left-1 text-4xl font-bold text-primary/10">
                          {index + 1}
                        </div>
                        <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10">
                          <Icon className="h-7 w-7 text-primary" />
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold mb-2">{feature.title}</h3>
                        <p className="text-sm text-muted-foreground">{feature.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
