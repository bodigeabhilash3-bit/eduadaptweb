'use client';

import { useState } from 'react';
import { 
  TrendingUp, 
  BookOpen, 
  Clock, 
  Flame, 
  Target, 
  ChevronRight,
  Star,
  Send,
  CheckCircle2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { useAppStore } from '@/lib/store';
import { getSubjectsByStream } from '@/lib/quiz-data';
import { cn } from '@/lib/utils';

export function ProgressDashboard() {
  const { student, progress, quizResult, setCurrentView } = useAppStore();
  const [feedback, setFeedback] = useState('');
  const [rating, setRating] = useState(0);
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  if (!student || !progress) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-muted-foreground mb-4">Please complete the assessment first</p>
            <Button onClick={() => setCurrentView('quiz')}>Take Assessment</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const subjects = getSubjectsByStream(student.stream);

  const handleSubmitFeedback = () => {
    setFeedbackSubmitted(true);
    setTimeout(() => {
      setFeedback('');
      setRating(0);
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Progress Dashboard</h1>
          <p className="text-muted-foreground">Track your learning journey and achievements</p>
        </div>

        {/* Stats Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Overall Progress</p>
                  <p className="text-3xl font-bold text-primary">{progress.overallProgress}%</p>
                </div>
                <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
              </div>
              <Progress value={progress.overallProgress} className="mt-4 h-2" />
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-secondary/10 to-secondary/5 border-secondary/20">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Topics Completed</p>
                  <p className="text-3xl font-bold text-secondary">{progress.completedTopics}/{progress.totalTopics}</p>
                </div>
                <div className="h-12 w-12 rounded-xl bg-secondary/20 flex items-center justify-center">
                  <BookOpen className="h-6 w-6 text-secondary" />
                </div>
              </div>
              <Progress value={(progress.completedTopics / progress.totalTopics) * 100} className="mt-4 h-2" />
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-accent/10 to-accent/5 border-accent/20">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Study Hours</p>
                  <p className="text-3xl font-bold">{progress.totalStudyHours}h</p>
                </div>
                <div className="h-12 w-12 rounded-xl bg-accent/20 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-accent-foreground" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-4">This week</p>
            </CardContent>
          </Card>

          <Card className={cn(
            "bg-gradient-to-br border-0",
            progress.streakDays > 5 
              ? "from-orange-500/10 to-red-500/10" 
              : "from-muted to-muted"
          )}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Learning Streak</p>
                  <p className="text-3xl font-bold">{progress.streakDays} days</p>
                </div>
                <div className="h-12 w-12 rounded-xl bg-orange-500/20 flex items-center justify-center">
                  <Flame className="h-6 w-6 text-orange-500" />
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-4">Keep it going!</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Subject Progress */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-primary" />
                  Subject-wise Progress
                </CardTitle>
                <CardDescription>Your performance across all subjects</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {subjects.map((subject) => {
                  const subjectData = progress.subjectProgress[subject];
                  const quizScore = quizResult?.subjectScores[subject];
                  const percentage = quizScore 
                    ? Math.round((quizScore.correct / quizScore.total) * 100)
                    : subjectData?.progress || 0;
                  
                  return (
                    <div key={subject} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "h-10 w-10 rounded-lg flex items-center justify-center",
                            percentage >= 70 ? "bg-primary/10" : percentage >= 40 ? "bg-accent/20" : "bg-destructive/10"
                          )}>
                            <BookOpen className={cn(
                              "h-5 w-5",
                              percentage >= 70 ? "text-primary" : percentage >= 40 ? "text-accent-foreground" : "text-destructive"
                            )} />
                          </div>
                          <div>
                            <p className="font-semibold">{subject}</p>
                            <p className="text-xs text-muted-foreground">
                              {subjectData?.completedTopics || 0}/{subjectData?.totalTopics || 5} topics completed
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={cn(
                            "text-2xl font-bold",
                            percentage >= 70 ? "text-primary" : percentage >= 40 ? "text-accent-foreground" : "text-destructive"
                          )}>
                            {percentage}%
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {percentage >= 70 ? 'Excellent' : percentage >= 40 ? 'Good' : 'Needs Work'}
                          </p>
                        </div>
                      </div>
                      <Progress 
                        value={percentage} 
                        className={cn("h-3")}
                      />
                      
                      {/* Weak/Strong Topics */}
                      <div className="flex flex-wrap gap-2">
                        {percentage < 50 && (
                          <span className="text-xs bg-destructive/10 text-destructive px-2 py-1 rounded-full">
                            Focus Area
                          </span>
                        )}
                        {percentage >= 80 && (
                          <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">
                            Strong Subject
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Weekly Goal */}
            <Card className={cn(
              progress.weeklyGoalMet 
                ? "border-primary/20 bg-primary/5" 
                : "border-secondary/20 bg-secondary/5"
            )}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "h-14 w-14 rounded-2xl flex items-center justify-center",
                      progress.weeklyGoalMet ? "bg-primary/20" : "bg-secondary/20"
                    )}>
                      <Target className={cn(
                        "h-7 w-7",
                        progress.weeklyGoalMet ? "text-primary" : "text-secondary"
                      )} />
                    </div>
                    <div>
                      <p className="font-semibold text-lg">Weekly Goal</p>
                      <p className="text-sm text-muted-foreground">
                        {progress.weeklyGoalMet 
                          ? 'Congratulations! You met your weekly goal!' 
                          : 'Keep pushing! You are almost there!'}
                      </p>
                    </div>
                  </div>
                  <Button variant="outline" onClick={() => setCurrentView('topics')}>
                    Continue Learning
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Feedback Section */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Share Your Feedback</CardTitle>
                <CardDescription>Help us improve your learning experience</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {feedbackSubmitted ? (
                  <div className="text-center py-8">
                    <div className="h-16 w-16 rounded-full bg-primary/10 mx-auto mb-4 flex items-center justify-center">
                      <CheckCircle2 className="h-8 w-8 text-primary" />
                    </div>
                    <p className="font-semibold mb-2">Thank you!</p>
                    <p className="text-sm text-muted-foreground">Your feedback helps us improve</p>
                  </div>
                ) : (
                  <>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Rate your experience</label>
                      <div className="flex gap-2">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            onClick={() => setRating(star)}
                            className={cn(
                              "h-10 w-10 rounded-lg flex items-center justify-center transition-all",
                              rating >= star 
                                ? "bg-accent text-accent-foreground" 
                                : "bg-muted text-muted-foreground hover:bg-muted/80"
                            )}
                          >
                            <Star className={cn("h-5 w-5", rating >= star && "fill-current")} />
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium mb-2 block">Your suggestions</label>
                      <Textarea
                        value={feedback}
                        onChange={(e) => setFeedback(e.target.value)}
                        placeholder="Share what you like or what could be improved..."
                        rows={4}
                      />
                    </div>
                    
                    <Button 
                      className="w-full gap-2" 
                      onClick={handleSubmitFeedback}
                      disabled={rating === 0}
                    >
                      <Send className="h-4 w-4" />
                      Submit Feedback
                    </Button>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-3"
                  onClick={() => setCurrentView('topics')}
                >
                  <BookOpen className="h-4 w-4 text-primary" />
                  View Study Plan
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-3"
                  onClick={() => setCurrentView('chat')}
                >
                  <Star className="h-4 w-4 text-secondary" />
                  Ask AI Tutor
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
