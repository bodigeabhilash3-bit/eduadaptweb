'use client';

import { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  BookOpen, 
  Calculator, 
  Beaker, 
  Dna,
  Lightbulb,
  RefreshCcw,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAppStore } from '@/lib/store';
import { ChatMessage } from '@/lib/types';
import { cn } from '@/lib/utils';

const suggestedQuestions = {
  MPC: [
    { icon: Calculator, text: 'Explain integration by parts' },
    { icon: Beaker, text: 'What is Le Chatelier\'s principle?' },
    { icon: Lightbulb, text: 'How does electromagnetic induction work?' },
    { icon: BookOpen, text: 'Tips for solving differential equations' },
  ],
  BIPC: [
    { icon: Dna, text: 'Explain DNA replication process' },
    { icon: Beaker, text: 'What are buffer solutions?' },
    { icon: Lightbulb, text: 'How does the human heart work?' },
    { icon: BookOpen, text: 'Tips for memorizing biological terms' },
  ],
};

// Mock AI responses based on keywords
const getAIResponse = (question: string, stream: 'MPC' | 'BIPC'): string => {
  const q = question.toLowerCase();
  
  if (q.includes('integration') || q.includes('integral')) {
    return `**Integration by Parts** is a powerful technique for integrating products of functions.\n\n**Formula:** ∫u dv = uv - ∫v du\n\n**Steps:**\n1. Choose u and dv from the integrand\n2. Find du by differentiating u\n3. Find v by integrating dv\n4. Apply the formula\n\n**Tip:** Use LIATE rule to choose u:\n- **L**ogarithmic\n- **I**nverse trig\n- **A**lgebraic\n- **T**rig\n- **E**xponential\n\nWant me to solve a specific integration problem?`;
  }
  
  if (q.includes('chatelier') || q.includes('equilibrium')) {
    return `**Le Chatelier's Principle** states that if a system at equilibrium is disturbed, it will shift to counteract the change.\n\n**Key Factors:**\n\n1. **Concentration:** Adding reactant → shifts right; Adding product → shifts left\n\n2. **Pressure:** Increasing pressure → shifts toward fewer moles of gas\n\n3. **Temperature:** \n   - Exothermic: Increasing T shifts left\n   - Endothermic: Increasing T shifts right\n\n**Example:** For N₂ + 3H₂ ⇌ 2NH₃\n- Adding N₂ → More NH₃ produced\n- Removing NH₃ → Reaction shifts right\n\nWould you like me to explain a specific application?`;
  }
  
  if (q.includes('dna') || q.includes('replication')) {
    return `**DNA Replication** is the process of copying DNA before cell division.\n\n**Key Steps:**\n\n1. **Initiation:** Helicase unwinds the double helix at the origin of replication\n\n2. **Primer Synthesis:** Primase adds RNA primers\n\n3. **Elongation:** DNA Polymerase III adds nucleotides (5' to 3' direction)\n   - Leading strand: Continuous synthesis\n   - Lagging strand: Okazaki fragments\n\n4. **Termination:** DNA Polymerase I replaces primers with DNA; Ligase seals the gaps\n\n**Key Enzymes:**\n- Helicase: Unwinds DNA\n- Primase: Makes RNA primers\n- DNA Polymerase: Adds nucleotides\n- Ligase: Joins fragments\n\nShall I explain any step in more detail?`;
  }
  
  if (q.includes('electromagnetic') || q.includes('induction')) {
    return `**Electromagnetic Induction** is the production of EMF when magnetic flux through a conductor changes.\n\n**Faraday's Law:**\nEMF = -dΦ/dt\n\n**Key Concepts:**\n\n1. **Magnetic Flux (Φ):** Φ = B·A·cosθ\n   - B = Magnetic field\n   - A = Area of loop\n   - θ = Angle between B and normal\n\n2. **Lenz's Law:** The induced current opposes the change that produces it\n\n3. **Applications:**\n   - Electric generators\n   - Transformers\n   - Induction cooktops\n\n**Practice Problem:** A coil of 100 turns has an area of 0.1 m². If the magnetic field changes from 0.5T to 0T in 0.2s, find the induced EMF.\n\nWant me to solve this problem?`;
  }
  
  if (q.includes('differential equation')) {
    return `**Tips for Solving Differential Equations:**\n\n**1. Identify the Type:**\n- First order linear: dy/dx + P(x)y = Q(x)\n- Separable: dy/dx = f(x)g(y)\n- Homogeneous: dy/dx = f(y/x)\n\n**2. Common Methods:**\n\n📌 **Separation of Variables:**\n- Rearrange to get all y terms on one side, x terms on the other\n- Integrate both sides\n\n📌 **Integrating Factor (for linear):**\n- IF = e^∫P(x)dx\n- Multiply equation by IF\n- Integrate\n\n📌 **Substitution:**\n- For homogeneous: Let y = vx\n- For Bernoulli: Let z = y^(1-n)\n\n**Pro Tips:**\n- Always check your solution by substituting back\n- Don't forget the constant of integration!\n- Practice recognizing patterns\n\nWant me to solve a specific differential equation?`;
  }
  
  if (q.includes('heart') || q.includes('cardiac')) {
    return `**The Human Heart - A Pumping Marvel!**\n\n**Structure:**\n- 4 chambers: 2 atria (upper), 2 ventricles (lower)\n- Right side: Deoxygenated blood\n- Left side: Oxygenated blood\n\n**Blood Flow Pathway:**\n1. Body → Superior/Inferior Vena Cava → Right Atrium\n2. Tricuspid Valve → Right Ventricle\n3. Pulmonary Valve → Pulmonary Artery → Lungs\n4. Pulmonary Veins → Left Atrium\n5. Bicuspid/Mitral Valve → Left Ventricle\n6. Aortic Valve → Aorta → Body\n\n**Cardiac Cycle:**\n- Systole: Contraction (blood pumped out)\n- Diastole: Relaxation (blood fills chambers)\n\n**Key Facts:**\n- Beats ~100,000 times/day\n- Pumps ~7,500 liters of blood/day\n- SA node is the natural pacemaker\n\nNeed more details on any aspect?`;
  }
  
  if (q.includes('buffer')) {
    return `**Buffer Solutions** resist pH changes when small amounts of acid or base are added.\n\n**Types:**\n\n1. **Acidic Buffer:** Weak acid + its conjugate base\n   - Example: CH₃COOH + CH₃COONa\n   - pH < 7\n\n2. **Basic Buffer:** Weak base + its conjugate acid\n   - Example: NH₃ + NH₄Cl\n   - pH > 7\n\n**Henderson-Hasselbalch Equation:**\npH = pKa + log([A⁻]/[HA])\n\n**How Buffers Work:**\n- Added H⁺ reacts with base component\n- Added OH⁻ reacts with acid component\n- pH stays relatively constant\n\n**Buffer Capacity:** Maximum amount of acid/base a buffer can neutralize\n\n**Biological Importance:**\n- Blood: pH 7.35-7.45 (carbonic acid/bicarbonate buffer)\n\nWant me to solve a buffer calculation problem?`;
  }
  
  if (q.includes('tip') || q.includes('memoriz') || q.includes('study')) {
    return `**Study Tips for ${stream} Students:**\n\n**1. Active Recall:**\n- Test yourself regularly\n- Use flashcards (physical or digital)\n- Explain concepts aloud\n\n**2. Spaced Repetition:**\n- Review material at increasing intervals\n- Day 1 → Day 3 → Day 7 → Day 14\n\n**3. Visual Learning:**\n- Create mind maps\n- Draw diagrams and flowcharts\n- Use color coding\n\n**4. Practice Problems:**\n- Start with easy, build to complex\n- Time yourself\n- Analyze mistakes\n\n**5. For Biological Terms:**\n- Break down words (prefixes, suffixes)\n- Create mnemonics\n- Associate with real-life examples\n\n**Daily Routine:**\n- 45-minute study blocks\n- 10-minute breaks\n- Review notes before bed\n\nWhich subject would you like specific tips for?`;
  }
  
  // Default response
  return `Great question! As your AI tutor for ${stream}, I'm here to help.\n\n**I can assist you with:**\n\n${stream === 'MPC' 
    ? '📐 **Mathematics:** Calculus, Algebra, Coordinate Geometry\n⚡ **Physics:** Mechanics, Electromagnetism, Modern Physics\n🧪 **Chemistry:** Organic, Inorganic, Physical Chemistry'
    : '🧬 **Biology:** Cell Biology, Genetics, Human Physiology\n⚡ **Physics:** Optics, Electricity, Waves\n🧪 **Chemistry:** Biochemistry, Acids & Bases, Organic Chemistry'
  }\n\n**Try asking:**\n- Explain a specific concept\n- Help solve a problem\n- Give study tips for a topic\n- Clarify doubts about any subject\n\nWhat would you like to learn about today?`;
};

export function AIChatbot() {
  const { student, chatMessages, addChatMessage, clearChat, setCurrentView } = useAppStore();
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages]);

  if (!student) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-muted-foreground mb-4">Please register first to use AI Tutor</p>
            <Button onClick={() => setCurrentView('register')}>Register Now</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const suggestions = suggestedQuestions[student.stream];

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    addChatMessage(userMessage);
    setInput('');
    setIsLoading(true);

    // Simulate AI thinking
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));

    const aiResponse: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'assistant',
      content: getAIResponse(input, student.stream),
      timestamp: new Date(),
    };

    addChatMessage(aiResponse);
    setIsLoading(false);
  };

  const handleSuggestionClick = (text: string) => {
    setInput(text);
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Bot className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold flex items-center gap-2">
                  AI Tutor
                  <Sparkles className="h-4 w-4 text-primary" />
                </h1>
                <p className="text-sm text-muted-foreground">Your 24/7 study companion for {student.stream}</p>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={clearChat} className="gap-2">
              <RefreshCcw className="h-4 w-4" />
              New Chat
            </Button>
          </div>
        </div>
      </div>

      {/* Chat Container */}
      <div className="flex-1 container mx-auto px-4 max-w-4xl overflow-y-auto py-6">
        {chatMessages.length === 0 ? (
          // Empty State
          <div className="h-full flex flex-col items-center justify-center text-center py-12">
            <div className="h-20 w-20 rounded-2xl bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center mb-6">
              <Bot className="h-10 w-10 text-primary" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Hi {student.name}! I'm your AI Tutor</h2>
            <p className="text-muted-foreground max-w-md mb-8">
              Ask me anything about {student.stream === 'MPC' ? 'Mathematics, Physics, or Chemistry' : 'Biology, Physics, or Chemistry'}. 
              I'm here to help you understand concepts and solve problems.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-3 w-full max-w-lg">
              {suggestions.map((suggestion, index) => {
                const Icon = suggestion.icon;
                return (
                  <button
                    key={index}
                    onClick={() => handleSuggestionClick(suggestion.text)}
                    className="flex items-center gap-3 rounded-xl border-2 border-border bg-card p-4 text-left transition-all hover:border-primary/50 hover:shadow-md"
                  >
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <span className="text-sm font-medium">{suggestion.text}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          // Messages
          <div className="space-y-6">
            {chatMessages.map((message) => (
              <div
                key={message.id}
                className={cn(
                  'flex gap-4',
                  message.role === 'user' ? 'justify-end' : 'justify-start'
                )}
              >
                {message.role === 'assistant' && (
                  <div className="h-10 w-10 shrink-0 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                    <Bot className="h-5 w-5 text-primary-foreground" />
                  </div>
                )}
                
                <div
                  className={cn(
                    'max-w-[80%] rounded-2xl px-5 py-4',
                    message.role === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted'
                  )}
                >
                  <div 
                    className={cn(
                      'prose prose-sm max-w-none',
                      message.role === 'user' && 'prose-invert'
                    )}
                  >
                    {message.content.split('\n').map((line, i) => (
                      <p key={i} className="mb-2 last:mb-0">
                        {line.startsWith('**') && line.endsWith('**') ? (
                          <strong>{line.slice(2, -2)}</strong>
                        ) : line.startsWith('- ') ? (
                          <span className="block ml-4">{line}</span>
                        ) : (
                          line
                        )}
                      </p>
                    ))}
                  </div>
                </div>
                
                {message.role === 'user' && (
                  <div className="h-10 w-10 shrink-0 rounded-xl bg-secondary flex items-center justify-center">
                    <User className="h-5 w-5 text-secondary-foreground" />
                  </div>
                )}
              </div>
            ))}
            
            {isLoading && (
              <div className="flex gap-4">
                <div className="h-10 w-10 shrink-0 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                  <Bot className="h-5 w-5 text-primary-foreground" />
                </div>
                <div className="bg-muted rounded-2xl px-5 py-4">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="border-t border-border bg-card/50 backdrop-blur">
        <div className="container mx-auto px-4 py-4 max-w-4xl">
          <div className="flex gap-3">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask me anything about your subjects..."
              className="flex-1 h-12"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              disabled={isLoading}
            />
            <Button 
              onClick={handleSend} 
              size="lg"
              className="h-12 px-6 gap-2"
              disabled={!input.trim() || isLoading}
            >
              <Send className="h-5 w-5" />
              Send
            </Button>
          </div>
          <p className="text-xs text-muted-foreground text-center mt-3">
            AI Tutor provides educational guidance. Always verify important information with your teachers.
          </p>
        </div>
      </div>
    </div>
  );
}
