'use client';

import { useState } from 'react';
import { 
  BookOpen, 
  Play, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  Calendar,
  ChevronRight,
  Filter,
  Target,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { useAppStore } from '@/lib/store';
import { getTopicsByStream, getTopicsBySubject } from '@/lib/topics-data';
import { getSubjectsByStream } from '@/lib/quiz-data';
import { Topic, SkillLevel } from '@/lib/types';
import { cn } from '@/lib/utils';

const difficultyColors = {
  beginner: 'bg-green-500/10 text-green-700 border-green-500/20',
  intermediate: 'bg-amber-500/10 text-amber-700 border-amber-500/20',
  advanced: 'bg-red-500/10 text-red-700 border-red-500/20',
};

const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export function TopicsSection() {
  const { student, quizResult, progress, setCurrentView } = useAppStore();
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);
  const [completedTopics, setCompletedTopics] = useState<Set<string>>(new Set());
  const [comfortLevel, setComfortLevel] = useState<'relaxed' | 'moderate' | 'intensive'>('moderate');

  if (!student) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-muted-foreground mb-4">Please register first</p>
            <Button onClick={() => setCurrentView('register')}>Register Now</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const subjects = getSubjectsByStream(student.stream);
  const allTopics = getTopicsByStream(student.stream);
  
  const filteredTopics = selectedSubject === 'all' 
    ? allTopics 
    : allTopics.filter(t => t.subject === selectedSubject);

  // Determine weak subjects based on quiz results
  const weakSubjects = quizResult 
    ? Object.entries(quizResult.subjectScores)
        .filter(([_, scores]) => (scores.correct / scores.total) < 0.5)
        .map(([subject]) => subject)
    : [];

  // Mark topics as weak if they belong to weak subjects
  const topicsWithStatus = filteredTopics.map(topic => ({
    ...topic,
    isWeak: weakSubjects.includes(topic.subject),
    isCompleted: completedTopics.has(topic.id),
  }));

  // Generate schedule based on comfort level
  const generateSchedule = () => {
    const hoursPerDay = comfortLevel === 'relaxed' ? 2 : comfortLevel === 'moderate' ? 4 : 6;
    
    return weekDays.map((day, index) => {
      const isWeekend = index >= 5;
      const dayTopics = topicsWithStatus
        .filter(t => !t.isCompleted)
        .slice(0, isWeekend ? 4 : 3);
      
      return {
        day,
        hours: isWeekend ? hoursPerDay + 1 : hoursPerDay,
        topics: dayTopics.map(t => t.title).slice(0, isWeekend ? 4 : 3),
        focus: isWeekend ? 'Practice & Review' : 'New Concepts',
      };
    });
  };

  const schedule = generateSchedule();

  const handleMarkComplete = (topicId: string) => {
    setCompletedTopics(prev => {
      const newSet = new Set(prev);
      if (newSet.has(topicId)) {
        newSet.delete(topicId);
      } else {
        newSet.add(topicId);
      }
      return newSet;
    });
  };

  const completedCount = completedTopics.size;
  const totalCount = allTopics.length;
  const progressPercentage = (completedCount / totalCount) * 100;

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Study Plan & Topics</h1>
          <p className="text-muted-foreground">
            2-minute explanations for each topic with personalized scheduling
          </p>
        </div>

        {/* Progress Overview */}
        <Card className="mb-8 bg-gradient-to-r from-primary/10 to-secondary/10 border-0">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-2xl bg-primary/20 flex items-center justify-center">
                  <Target className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{completedCount}/{totalCount} Topics</p>
                  <p className="text-muted-foreground">Completed</p>
                </div>
              </div>
              <div className="w-full sm:w-64">
                <Progress value={progressPercentage} className="h-3 mb-2" />
                <p className="text-xs text-muted-foreground text-right">{Math.round(progressPercentage)}% Complete</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Topics List */}
          <div className="lg:col-span-2 space-y-6">
            {/* Filters */}
            <div className="flex flex-wrap items-center gap-3">
              <Filter className="h-5 w-5 text-muted-foreground" />
              <Button
                variant={selectedSubject === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedSubject('all')}
              >
                All Topics
              </Button>
              {subjects.map((subject) => (
                <Button
                  key={subject}
                  variant={selectedSubject === subject ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedSubject(subject)}
                  className={cn(
                    weakSubjects.includes(subject) && selectedSubject !== subject && 'border-destructive/50'
                  )}
                >
                  {subject}
                  {weakSubjects.includes(subject) && (
                    <AlertTriangle className="ml-1 h-3 w-3 text-destructive" />
                  )}
                </Button>
              ))}
            </div>

            {/* Weak Topics Alert */}
            {weakSubjects.length > 0 && (
              <Card className="border-destructive/20 bg-destructive/5">
                <CardContent className="pt-4 pb-4">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-5 w-5 text-destructive" />
                    <div>
                      <p className="font-medium">Focus Areas Identified</p>
                      <p className="text-sm text-muted-foreground">
                        Based on your assessment, we recommend focusing on: {weakSubjects.join(', ')}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Topics Grid */}
            <div className="space-y-4">
              {topicsWithStatus.map((topic) => (
                <Card 
                  key={topic.id} 
                  className={cn(
                    'transition-all cursor-pointer hover:shadow-md',
                    topic.isCompleted && 'opacity-60',
                    topic.isWeak && !topic.isCompleted && 'ring-2 ring-destructive/30',
                    selectedTopic?.id === topic.id && 'ring-2 ring-primary'
                  )}
                  onClick={() => setSelectedTopic(topic)}
                >
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMarkComplete(topic.id);
                        }}
                        className={cn(
                          'h-10 w-10 shrink-0 rounded-xl flex items-center justify-center transition-all',
                          topic.isCompleted 
                            ? 'bg-primary text-primary-foreground' 
                            : 'bg-muted hover:bg-muted/80'
                        )}
                      >
                        {topic.isCompleted ? (
                          <CheckCircle2 className="h-5 w-5" />
                        ) : (
                          <Play className="h-5 w-5" />
                        )}
                      </button>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold truncate">{topic.title}</h3>
                          {topic.isWeak && !topic.isCompleted && (
                            <span className="shrink-0 text-xs bg-destructive/10 text-destructive px-2 py-0.5 rounded-full">
                              Priority
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-2">{topic.description}</p>
                        <div className="flex items-center gap-3 mt-3">
                          <span className="text-xs bg-muted px-2 py-1 rounded-full">{topic.subject}</span>
                          <span className={cn(
                            'text-xs px-2 py-1 rounded-full border capitalize',
                            difficultyColors[topic.difficulty]
                          )}>
                            {topic.difficulty}
                          </span>
                          <span className="flex items-center gap-1 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            {topic.duration} min
                          </span>
                        </div>
                      </div>
                      
                      <ChevronRight className="h-5 w-5 text-muted-foreground shrink-0" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar - Schedule & Topic Details */}
          <div className="space-y-6">
            {/* Topic Detail */}
            {selectedTopic && (
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-lg">{selectedTopic.title}</CardTitle>
                  <CardDescription>{selectedTopic.subject}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{selectedTopic.description}</p>
                  
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-primary" />
                      <span className="text-sm">{selectedTopic.duration} min lesson</span>
                    </div>
                    <span className={cn(
                      'text-xs px-2 py-1 rounded-full border capitalize',
                      difficultyColors[selectedTopic.difficulty]
                    )}>
                      {selectedTopic.difficulty}
                    </span>
                  </div>
                  
                  <div className="bg-muted/50 rounded-lg p-4">
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <Zap className="h-4 w-4 text-primary" />
                      Quick Summary
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      This 2-minute explanation covers the key concepts of {selectedTopic.title.toLowerCase()}. 
                      Perfect for quick revision or building foundational understanding.
                    </p>
                  </div>
                  
                  <Button 
                    className="w-full gap-2"
                    onClick={() => handleMarkComplete(selectedTopic.id)}
                  >
                    {completedTopics.has(selectedTopic.id) ? (
                      <>
                        <CheckCircle2 className="h-4 w-4" />
                        Mark as Incomplete
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4" />
                        Start Learning
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Comfort Level */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  Schedule Comfort
                </CardTitle>
                <CardDescription>Adjust based on your availability</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {(['relaxed', 'moderate', 'intensive'] as const).map((level) => (
                  <button
                    key={level}
                    onClick={() => setComfortLevel(level)}
                    className={cn(
                      'w-full flex items-center justify-between rounded-lg border-2 p-3 transition-all',
                      comfortLevel === level 
                        ? 'border-primary bg-primary/5' 
                        : 'border-border hover:border-primary/50'
                    )}
                  >
                    <div className="text-left">
                      <p className="font-medium capitalize">{level}</p>
                      <p className="text-xs text-muted-foreground">
                        {level === 'relaxed' && '2-3 hours/day'}
                        {level === 'moderate' && '4-5 hours/day'}
                        {level === 'intensive' && '6+ hours/day'}
                      </p>
                    </div>
                    {comfortLevel === level && (
                      <CheckCircle2 className="h-5 w-5 text-primary" />
                    )}
                  </button>
                ))}
              </CardContent>
            </Card>

            {/* Weekly Schedule */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Weekly Schedule</CardTitle>
                <CardDescription>Your personalized study plan</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {schedule.slice(0, 5).map((day) => (
                  <div key={day.day} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                    <div>
                      <p className="font-medium text-sm">{day.day}</p>
                      <p className="text-xs text-muted-foreground">{day.focus}</p>
                    </div>
                    <span className="text-sm font-medium text-primary">{day.hours}h</span>
                  </div>
                ))}
                <Button variant="outline" className="w-full" onClick={() => setCurrentView('chat')}>
                  Customize with AI
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
