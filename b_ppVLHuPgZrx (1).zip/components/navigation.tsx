'use client';

import { GraduationCap, BookOpen, BarChart3, Calendar, MessageCircle, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAppStore } from '@/lib/store';
import { cn } from '@/lib/utils';

const navItems = [
  { id: 'register', label: 'Home', icon: Home },
  { id: 'quiz', label: 'Assessment', icon: BookOpen },
  { id: 'progress', label: 'Progress', icon: BarChart3 },
  { id: 'topics', label: 'Study Plan', icon: Calendar },
  { id: 'chat', label: 'AI Tutor', icon: MessageCircle },
] as const;

export function Navigation() {
  const { currentView, setCurrentView, student } = useAppStore();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
            <GraduationCap className="h-6 w-6 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold tracking-tight text-foreground">
            Edu<span className="text-primary">Adapt</span>
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            const isDisabled = !student && item.id !== 'register';

            return (
              <Button
                key={item.id}
                variant={isActive ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setCurrentView(item.id as any)}
                disabled={isDisabled}
                className={cn(
                  'gap-2 transition-all',
                  isActive && 'bg-primary text-primary-foreground',
                  isDisabled && 'opacity-50 cursor-not-allowed'
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Button>
            );
          })}
        </nav>

        {student && (
          <div className="flex items-center gap-3">
            <div className="hidden sm:block text-right">
              <p className="text-sm font-medium text-foreground">{student.name}</p>
              <p className="text-xs text-muted-foreground">{student.stream} Student</p>
            </div>
            <div className="h-9 w-9 rounded-full bg-secondary flex items-center justify-center">
              <span className="text-sm font-semibold text-secondary-foreground">
                {student.name.charAt(0).toUpperCase()}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Mobile Navigation */}
      <nav className="md:hidden flex items-center justify-around border-t border-border bg-card py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;
          const isDisabled = !student && item.id !== 'register';

          return (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id as any)}
              disabled={isDisabled}
              className={cn(
                'flex flex-col items-center gap-1 px-3 py-1 rounded-lg transition-colors',
                isActive ? 'text-primary' : 'text-muted-foreground',
                isDisabled && 'opacity-50 cursor-not-allowed'
              )}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </nav>
    </header>
  );
}
