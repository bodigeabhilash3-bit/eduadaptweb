import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Student, Stream, SkillLevel, QuizResult, Progress, ChatMessage } from './types';

interface AppState {
  // Current view
  currentView: 'register' | 'quiz' | 'results' | 'progress' | 'topics' | 'chat';
  setCurrentView: (view: AppState['currentView']) => void;
  
  // Student
  student: Student | null;
  setStudent: (student: Student) => void;
  
  // Quiz
  quizResult: QuizResult | null;
  setQuizResult: (result: QuizResult) => void;
  
  // Progress
  progress: Progress | null;
  setProgress: (progress: Progress) => void;
  
  // Chat
  chatMessages: ChatMessage[];
  addChatMessage: (message: ChatMessage) => void;
  clearChat: () => void;
  
  // Reset
  reset: () => void;
}

const initialState = {
  currentView: 'register' as const,
  student: null,
  quizResult: null,
  progress: null,
  chatMessages: [],
};

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      ...initialState,
      
      setCurrentView: (view) => set({ currentView: view }),
      
      setStudent: (student) => set({ student }),
      
      setQuizResult: (result) => set({ quizResult: result }),
      
      setProgress: (progress) => set({ progress }),
      
      addChatMessage: (message) => 
        set((state) => ({ chatMessages: [...state.chatMessages, message] })),
      
      clearChat: () => set({ chatMessages: [] }),
      
      reset: () => set(initialState),
    }),
    {
      name: 'eduadapt-storage',
    }
  )
);

// Helper function to calculate skill level from quiz results
export const calculateSkillLevel = (score: number, total: number): SkillLevel => {
  const percentage = (score / total) * 100;
  if (percentage >= 80) return 'advanced';
  if (percentage >= 50) return 'intermediate';
  return 'beginner';
};

// Helper to generate study plan based on skill level
export const generateStudyPlanDescription = (skillLevel: SkillLevel, stream: Stream): string => {
  const plans = {
    beginner: {
      MPC: 'Focus on fundamental concepts. Start with basic formulas and definitions in Mathematics, Physics laws, and Chemical equations. Recommended: 3-4 hours daily with emphasis on concept building.',
      BIPC: 'Build strong foundations in Cell Biology, basic Physics concepts, and Chemical fundamentals. Recommended: 3-4 hours daily with visual learning aids and diagrams.',
    },
    intermediate: {
      MPC: 'Strengthen problem-solving skills. Practice numerical problems in Mathematics, apply Physics concepts, and understand reaction mechanisms. Recommended: 4-5 hours daily with mixed practice.',
      BIPC: 'Deepen understanding of Genetics, apply Physics to biological systems, and master Biochemistry. Recommended: 4-5 hours daily with case studies and applications.',
    },
    advanced: {
      MPC: 'Master complex problems and competitive exam patterns. Focus on time management and accuracy. Recommended: 5-6 hours daily with timed practice tests.',
      BIPC: 'Excel in application-based questions and NEET patterns. Focus on molecular biology and clinical applications. Recommended: 5-6 hours daily with mock tests.',
    },
  };
  
  return plans[skillLevel][stream];
};

// Generate mock progress data
export const generateInitialProgress = (studentId: string, stream: Stream): Progress => {
  const subjects = stream === 'MPC' 
    ? ['Mathematics', 'Physics', 'Chemistry']
    : ['Biology', 'Physics', 'Chemistry'];
    
  const subjectProgress: Record<string, any> = {};
  
  subjects.forEach((subject) => {
    subjectProgress[subject] = {
      subject,
      progress: Math.floor(Math.random() * 30) + 10,
      completedTopics: Math.floor(Math.random() * 3),
      totalTopics: 5,
      averageScore: Math.floor(Math.random() * 40) + 40,
      weakTopics: [],
      strongTopics: [],
    };
  });
  
  return {
    studentId,
    overallProgress: Math.floor(Math.random() * 20) + 10,
    subjectProgress,
    streakDays: Math.floor(Math.random() * 7) + 1,
    totalStudyHours: Math.floor(Math.random() * 20) + 5,
    completedTopics: Math.floor(Math.random() * 5),
    totalTopics: 15,
    weeklyGoalMet: Math.random() > 0.5,
  };
};
